﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pizza_Shop
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (namecombo.SelectedItem.ToString() == "Cheese")
            {
                if (sizecombo.SelectedItem.ToString() == "Mini")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1200).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1800).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Extra Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 2500).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, sizecombo.Text, quanitycombo.Text, paytext.Text);

            }
            if (namecombo.SelectedItem.ToString() == "Veggie")
            {
                if (sizecombo.SelectedItem.ToString() == "Mini")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 900).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1200).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Extra Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1800).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, sizecombo.Text, quanitycombo.Text, paytext.Text);
            }
            if (namecombo.SelectedItem.ToString() == "Chicken")
            {
                if (sizecombo.SelectedItem.ToString() == "Mini")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1000).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 1500).ToString();
                }
                if (sizecombo.SelectedItem.ToString() == "Extra Large")
                {
                    paytext.Text = (float.Parse(quanitycombo.Text) * 2000).ToString();
                }
                dataGridView1.Rows.Add(idtext.Text, namecombo.Text, sizecombo.Text, quanitycombo.Text, paytext.Text);

            }
        }

        private void idtext_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsNumber(e.KeyChar))
            {

            }
            else
            {
                e.Handled = e.KeyChar != (Char)Keys.Back;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
                idtext.Text = "";
                namecombo.Text = "";
                sizecombo.Text = "";
                quanitycombo.Text = "";
                paytext.Text = "";
            
        }

        private void HomeBtn_Click(object sender, EventArgs e)
        {
                Home obj = new Home();
                obj.Show();
                this.Hide();
            
        }

        private void CrossBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BckBtn_Click(object sender, EventArgs e)
        {
            Items back = new Items();
            back.Show();
            this.Hide();
        }
    }
}
